function printArray(array){ 
var newar=[];
newar=array.join(',');
return newar;
}